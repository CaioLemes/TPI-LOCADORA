CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aluguel`
--

DROP TABLE IF EXISTS `aluguel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aluguel` (
  `id` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `data_aluguel` date NOT NULL,
  `data_devolucao` date NOT NULL,
  `valor` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `FK_aluguel_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aluguel`
--

LOCK TABLES `aluguel` WRITE;
/*!40000 ALTER TABLE `aluguel` DISABLE KEYS */;
INSERT INTO `aluguel` VALUES (1,1,'2017-10-10','2017-10-12',6),(2,2,'2017-08-02','2017-08-04',6),(3,3,'2017-09-12','2017-09-04',6),(4,5,'2017-05-01','2017-05-03',6),(5,4,'2017-09-13','2017-09-15',6),(6,6,'2017-08-21','2017-08-23',4),(7,7,'2017-02-11','2017-03-18',4),(8,8,'2017-04-10','0000-00-00',4),(9,9,'2017-02-12','0000-00-00',4),(10,10,'2017-01-31','2017-02-02',4);
/*!40000 ALTER TABLE `aluguel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `nome` varchar(65) NOT NULL,
  `idade` int(11) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `rg` varchar(45) NOT NULL,
  `telefone` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Artur Pelegrino',16,'Rua santo André 341','125.254-03','3654-9821'),(2,'Maycon wilson',23,'Rua Marili Moura 157','123.254-03','3654-3254'),(3,'Leandro Aparecido',69,'Rua Russia silva 155','123.359-03','3654-1880'),(4,'Pedro Santos',31,'Rua Amaral Moura 666','255.254-07','3654-9861'),(5,'Igor Lopes',36,'Rua Orlando Silva  255','123.225-12','3654-6256'),(6,'Bruna Barros',15,'Rua Louça Suja 699','154.254-69','3654-1254'),(7,'Sabrina Bongo',16,'Rua Verdade e Desafio 969','173.224-23','5914-3254'),(8,'Olomisa Infiel',16,'Rua Aqule tapa 254','256.324-03','2541-3214'),(9,'José moto V.L.O.G',6,'Rua DO Grau 90','123.325-01','3654-2266'),(10,'Diego Block',29,'Rua Block do Youtube 254','213.325-09','3654-2012');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_has_filme`
--

DROP TABLE IF EXISTS `cliente_has_filme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_has_filme` (
  `Filme_id` int(11) NOT NULL,
  `Aluguel_id` int(11) NOT NULL,
  PRIMARY KEY (`Filme_id`,`Aluguel_id`),
  KEY `fk_Cliente_has_Filme_Filme1_idx` (`Filme_id`),
  KEY `fk_Cliente_has_Filme_Aluguel1_idx` (`Aluguel_id`),
  CONSTRAINT `fk_Cliente_has_Filme_Aluguel1` FOREIGN KEY (`Aluguel_id`) REFERENCES `aluguel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Cliente_has_Filme_Filme1` FOREIGN KEY (`Filme_id`) REFERENCES `filme` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_has_filme`
--

LOCK TABLES `cliente_has_filme` WRITE;
/*!40000 ALTER TABLE `cliente_has_filme` DISABLE KEYS */;
INSERT INTO `cliente_has_filme` VALUES (3,2),(6,1),(7,5),(8,4),(9,3),(11,6),(12,7),(15,8),(18,10),(19,9);
/*!40000 ALTER TABLE `cliente_has_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filme`
--

DROP TABLE IF EXISTS `filme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filme` (
  `id` int(11) NOT NULL,
  `titulo` varchar(65) NOT NULL,
  `diretor` varchar(65) NOT NULL,
  `genero` varchar(45) NOT NULL,
  `classificacao` int(11) NOT NULL,
  `tipo` varchar(45) NOT NULL,
  `data_lancamento` date NOT NULL,
  `situacao` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filme`
--

LOCK TABLES `filme` WRITE;
/*!40000 ALTER TABLE `filme` DISABLE KEYS */;
INSERT INTO `filme` VALUES (1,'Transformers 5','maicon bay','ficção científica',11,'lançamento','2017-01-20','Disponível'),(2,'Homem aranha de volta ao lar','Jon Watts','Herois-ficção',11,'lançamento','2017-07-06','Disponível'),(3,'Kingsman o Circulo de ouro','Matthew Vaughn','Drama',11,'lançamento','2017-09-28','Disponível'),(4,'Liga da Justiça','Zack Snyder','Herois-ação',16,'lançamento','2017-11-17','Disponível'),(5,'Assassinato no Expresso do Oriente','Kenneth Branagh','Suspense-Drama',16,'lançamento','2017-11-30','Disponível'),(6,'Terra Selvagem','Taylor Sheridan','Aventura-ação',11,'lançamento','2017-08-31','Disponível'),(7,'Depois Daquela Montanha','Abu-Assad','Suspense-Drama',16,'lançamento','2017-10-05','Disponível'),(8,'Deserto','Jonás Cuarón','Drama-Aventura-Suspense',16,'lançamento','2017-09-14','Disponível'),(9,'Historietas Assombradas - O Filme','Victor-Hugo Borges','Animação-Comédia',10,'lançamento','2017-11-02','Disponível'),(10,'Jogos Mortais: Jigsaw','Peter Spierig','Terror-Suspense',18,'lançamento','2017-11-30','Disponível'),(11,'Deadpoll','Tim Miller','comédia-ação',16,'catalogo','2016-02-11','Disponível'),(12,'A série divergente: convergente','Robert Schwentke','aventura-ação',16,'catalogo','2016-03-11','Disponível'),(13,'Batman VS SuperMan','Zack Snyder','fantasia-ação',16,'catalogo','2016-03-24','Disponível'),(14,'Independece day : O ressurgimento',' Roland Emmerich','Ficcção científica-ação',16,'catalogo','2016-02-23','Disponível'),(15,'Capitão américa: Guerra civil','Anthony Russo','fantasia-ação',16,'catalogo','2016-04-28','Disponível'),(16,'Procurando Dory','Andrew Stanton','Animação-comedia',11,'catalogo','2016-07-30','Disponível'),(17,'Star Trak: Sem fronteiras','Justin Lin','Ação-aventura',16,'catalogo','2016-09-01','Disponível'),(18,'Esquadrão suicida','David Ayer','Ação-fantasia',16,'catalogo','2016-08-04','Disponível'),(19,'Animais Fantásticos e Onde Habitam','David Yates','Fantasia-aventura',16,'catalogo','2016-11-17','Disponível'),(20,'Rogue One – Uma História Star Wars','Gareth Edwards (II)','Ficcção científica-aventura',16,'catalogo','2016-12-15','Disponível');
/*!40000 ALTER TABLE `filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `login` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'admin','admin');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 23:04:22
