<?php
namespace Project\Controller;

use Project\Db\QueryBuilder;
use Project\Util\Login;
session_start();

class DadosController
{
    public function index()
    {
        //acessar o bd
        $q = new QueryBuilder();
        //receber os dados
        $dados = $q->select('filme');
        //acessar a view
        require './app/views/index.php';

    }

    public function catalogo()
    {
        $q = new QueryBuilder();
        //receber os dados
        $dados11 = $q->select('filme where id=12');
        $dados12 = $q->select('filme where id=13');
        $dados13 = $q->select('filme where id=14');
        $dados14 = $q->select('filme where id=15');
        $dados15 = $q->select('filme where id=16');
        $dados16 = $q->select('filme where id=17');
        $dados17 = $q->select('filme where id=18');
        $dados18 = $q->select('filme where id=19');
        $dados19 = $q->select('filme where id=20');
        //acessar a view
        require 'app/views/catalogo.php';
    }

    public function lancamento()
    {
        $q = new QueryBuilder();
        //receber os dados
        $dados = $q->select('filme where id=1');
        $dados1 = $q->select('filme where id=2');
        $dados2 = $q->select('filme where id=3');
        $dados3 = $q->select('filme where id=4');
        $dados4 = $q->select('filme where id=5');
        $dados5 = $q->select('filme where id=6');
        $dados6 = $q->select('filme where id=7');
        $dados7 = $q->select('filme where id=8');
        $dados8 = $q->select('filme where id=9');
        $dados9 = $q->select('filme where id=10');
        //acessar a view
        require 'app/views/lancamento.php';
    }

    public function cadastrofilme()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //acessar o bd
        $q = new QueryBuilder();
        //receber os dados
        $dados = $q->select('filme');
        //acessar a view
        require './app/views/cadastrofilme.php';

    }

    public function cliente()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //acessar o bd
        $q = new QueryBuilder();
        //receber os dados
        $dados = $q->select('cliente');
        //acessar a view
        require './app/views/cadastrocliente.php';

    }

    public function aluguel()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //acessar o bd
        $q = new QueryBuilder();
        //receber os dados
        $dados = $q->select('aluguel');
        //acessar a view
        require './app/views/cadastroaluguel.php';

    }


     public function salvarfilme()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //receber os dados
        $dados['id'] = $_POST['id'];
        $dados['titulo'] = $_POST['titulo'];
        $dados['diretor'] = $_POST['diretor'];
        $dados['genero'] = $_POST['genero'];
        $dados['classificacao'] = $_POST['classificacao'];
        $dados['tipo'] = $_POST['tipo'];
        $dados['data_lancamento'] = $_POST['data_lancamento'];
        $dados['situacao'] = $_POST['situacao'];


        //acessar o banco
        $q = new QueryBuilder();

        //guardar os dados
        $q->insert('filme', $dados);
        
        //redirecionar para a rota /
        header('Location: /admin_pagina');
        
    }
    public function salvarcliente()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //receber os dados
        $dados['id'] = $_POST['id'];
        $dados['nome'] = $_POST['nome'];
        $dados['idade'] = $_POST['idade'];
        $dados['endereco'] = $_POST['endereco'];
        $dados['rg'] = $_POST['rg'];
        $dados['telefone'] = $_POST['telefone'];
        


        //acessar o banco
        $q = new QueryBuilder();

        //guardar os dados
        $q->insert('cliente', $dados);
        
        //redirecionar para a rota /
        header('Location: /admin_pagina');
    }
     public function salvaraluguel()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //receber os dados
        $dados['id'] = $_POST['id'];
        $dados['id_cliente'] = $_POST['id_cliente'];
        $dados['data_aluguel'] = $_POST['data_aluguel'];
        $dados['data_devolucao'] = $_POST['data_devolucao'];
        $dados['valor'] = $_POST['valor'];
        


        //acessar o banco
        $q = new QueryBuilder();

        //guardar os dados
        $q->insert('aluguel', $dados);
        //redirecionar para a rota /
        header('Location: /salvarhas');
    }

    public function salvarhas2()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit; }

        //receber os dados
        $dados['Filme_id'] = $_POST['Filme_id'];
        $dados['Aluguel_id'] = $_POST['Aluguel_id'];
        


        //acessar o banco
        $q = new QueryBuilder();

        //guardar os dados
        $q->insert('cliente_has_filme', $dados);
        $q->updateSituacao($dados['Filme_id']);
        //redirecionar para a rota /
        header('Location: /admin_pagina');
    }

     public function Logout(){

        session_destroy();
        header('Location: /');
      
    }


    
    
}