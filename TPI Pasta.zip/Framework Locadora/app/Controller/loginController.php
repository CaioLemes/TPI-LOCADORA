<?php
namespace Project\Controller;
use Project\Db\QueryBuilder;
use Project\Util\Flash;

class LoginController
{
    public function login()
        {
            $dados['login'] = htmlentities($_POST['login'], ENT_QUOTES);
            $dados['password'] = htmlentities($_POST['password'], ENT_QUOTES);

            $q = new QueryBuilder();
            
            $logou = $q->select('usuario', [
                'login' => $dados['login'], 
                'password' => $dados['password']
            ]);                                              
            
            
            // se o usuário não foi encontrado no banco de dados
            // emite uma mensagem de erro
            if (!$logou) {
                header('Location: /');
                exit;
            
            }
            // autentica o usuário
            $_SESSION['usuario'] = $dados['login'];
            
            header('Location: /admin_pagina');
        }

public function logout(){
            //remove todas variáveis criadas de sessão
            session_unset();
            //devolve para a página inicial
            header('Location: /');
        }
    
    }
