<!DOCTYPE html>
<html lang="pt-br">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Locadora</title>

    <link href="public/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    <link href="public/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Cabin:700' rel='stylesheet' type='text/css'>


    <link href="public/css/grayscale.min.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <!-- Navegação -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href=/index>Home Page</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="/catalogo">Catálogos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="/lancamento">Lançamentos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#login">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="/admin_pagina">ADMIN</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#mapa">Localização</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Intro -->
    <header class="masthead">
      <div class="intro-body">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h1 class="brand-heading">Lançamentos</h1>
              <a href="#mapa" class="btn js-scroll-trigger" style="background: black;"> 
                <i class="fa fa-angle-double-down animated"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>

      <!-- FILMES -->
    <div class="row">
    <div class="col s12">   
    <div style=" word-break: break-word;  background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados as $d) { ?>       
    <center><img src="public/img/transformes.jpg" height="450" width="300" style="margin-top: 10px;"></center>
          <b>Nome:</b> <?= $d['titulo'] ?><br>
          <b>Status:</b> <?= $d['situacao'] ?><br>
          <?php } ?>
    </div>
    <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados1 as $d) { ?>
    <center><img src="public/img/spiderman.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados2 as $d) { ?> 
    <center><img src="public/img/kingsman.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados3 as $d) { ?> 
   <center> <img src="public/img/ligajustica.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados4 as $d) { ?> 
<center><img src="public/img/murder.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados5 as $d) { ?> 
    <center><img src="public/img/windriver.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados6 as $d) { ?> 
<center><img src="public/img/themountain.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados7 as $d) { ?> situacao
   <center> <img src="public/img/deserto.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados8 as $d) { ?> 
    <center> <img src="public/img/historietas.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
       <div style=" word-break: break-word; background: #17202A;" class="col s4 offset-s1 card">
    <?php foreach($dados9 as $d) { ?> 
    <center><img src="public/img/jogosmortais.jpg" height="450" width="300" style="margin-top: 10px;"></center>
           <b>Nome:</b> <?= $d['titulo'] ?><br>
           <b>Status:</b> <?= $d['situacao'] ?><br>
    <?php } ?>
       </div>
  </div>
</div>

    </body>

</html>
