<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Cadastro</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    </head>
    <body>
        <div class="container">
            <div clas="row" class"col s12" >
                <h3> ALUGUEL </h3>
            </div>
            <div class="row">
                <form class="col s12" method="post" action=" /salvarhas2">
                    <div class="row">
                        <div class="input-field col s6">
                            <input  id="Filme_id" name="Filme_id" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="Filme_id">ID Filme</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="Aluguel_id" name="Aluguel_id" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="Aluguel_id">ID Aluguel</label>
                        </div>
                    </div>
                    
                    <button class="btn waves-effect waves-light" type="submit" name="action">Enviar
                    </button>
                </form>
            </div>
            </div>