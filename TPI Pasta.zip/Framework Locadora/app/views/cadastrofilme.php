<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Cadastro</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    </head>
    <body>
        <div class="container">
            <div clas="row" class"col s12" >
                <h3> FILME </h3>
            </div>
            <div class="row">
                <form class="col s12" method="post" action=" /salvarfilme">
                    <div class="row">
                        <div class="input-field col s6">
                            <input  id="id" name="id" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="id">Digite O ID</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <input name="titulo" id="titulo" required type="text" class="validate" maxlength="160">
                            
                            <label class="active" for="titulo">Escreva o titulo do filme</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="diretor" name="diretor" required type="text" class="validate" maxlength="55">
                            <label class="active" for="diretor">Diretor</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="genero" name="genero" required type="text" class="validate" maxlength="55">
                            <label class="active" for="genero">Genero</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="classificacao" name="classificacao" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="classificacao">Classficacao</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="tipo" name="tipo" required type="text" class="validate" maxlength="55">
                            <label class="active" for="tipo">tipo</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="data_lancamento" name="data_lancamento" required type="date" class="validate" maxlength="55">
                            <label class="active" for="data_lancamento">data_lancamento</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="situacao" name="situacao" required type="text" class="validate" maxlength="55">
                            <label class="active" for="situacao">siuacao</label>
                        </div>
                    </div>
                    
                    <button class="btn waves-effect waves-light" type="submit" name="action">Enviar
                    </button>
                </form>
            </div>
            </div>

              <!-- ALTERAÇÃO DE FILMES ALUGADOS -->
      <div>
      <table>
  <thead>
  <tr>
    <th>  ID  </th>
    <th>  TITULO  </th>
    <th>  DIRETOR  </th>
    <th>  GENERO  </th>
    <th>  CLASSIFICACAO  </th>
    <th>  TIPO  </th>
    <th>  DATA_LANCAMENTO  </th>
    <th>   STATUS  </th>
  </tr>
  </thead>

  <tbody>
  <?php foreach ($dados as $v) { ?>
        <tr>
         <td>
            <?= $v['id'] ?>
         </td>
         <td>
            <?= $v['titulo'] ?>
         </td>
         <td>
            <?= $v['diretor'] ?>
         </td>
         <td>
            <?= $v['genero'] ?>
         </td>
         <td>
            <?= $v['classificacao'] ?>
         </td>
         <td>
            <?= $v['tipo'] ?>
         </td>
         <td>
            <?= $v['data_lancamento'] ?>
         </td>
         <td>
            <?= $v['situacao'] ?>
         </td>
        <?php } ?>
        </tr>
  </tbody>
  </table>
  </div>