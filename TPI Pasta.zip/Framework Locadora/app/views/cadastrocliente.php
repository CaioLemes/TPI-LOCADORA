<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Cadastro</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    </head>
    <body>
        <div class="container">
            <div clas="row" class"col s12" >
                <h3> CLIENTE </h3>
            </div>
            <div class="row">
                <form class="col s12" method="post" action=" /salvarcliente">
                    <div class="row">
                        <div class="input-field col s6">
                            <input  id="id" name="id" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="id">Digite O ID</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <input name="nome" id="nome" required type="text" class="validate" maxlength="160">
                            
                            <label class="active" for="nome">Nome</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="idade" name="idade" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="idade">idade</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="endereco" name="endereco" required type="text" class="validate" maxlength="55">
                            <label class="active" for="endereco">endereco</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="rg" name="rg" required type="text" class="validate" maxlength="55">
                            <label class="active" for="rg">Rg</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="telefone" name="telefone" required type="text" class="validate" maxlength="55">
                            <label class="active" for="telefone">telefone</label>
                        </div>
                    </div>
                    
                    <button class="btn waves-effect waves-light" type="submit" name="action">Enviar
                    </button>
                </form>

                   <!-- ALTERAÇÃO DE FILMES ALUGADOS -->
      <div>
      <table>
  <thead>
  <tr>
    <th>  ID  </th>
    <th>  NOME  </th>
    <th>  IDADE  </th>
    <th>  ENDERECO  </th>
    <th>  RG  </th>
    <th>  TELEFONE  </th>
  </tr>
  </thead>

  <tbody>
  <?php foreach ($dados as $v) { ?>
        <tr>
         <td>
            <?= $v['id'] ?>
         </td>
         <td>
            <?= $v['nome'] ?>
         </td>
         <td>
            <?= $v['idade'] ?>
         </td>
         <td>
            <?= $v['endereco'] ?>
         </td>
         <td>
            <?= $v['rg'] ?>
         </td>
         <td>
            <?= $v['telefone'] ?>
         </td>
        <?php } ?>
        </tr>
  </tbody>
  </table>
  </div>
            </div>
            </div>