<!DOCTYPE html>
<html >
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Locadora</title>

    <link href="public/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <link href="public/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Cabin:700' rel='stylesheet' type='text/css'>


    <link href="public/css/grayscale.min.css" rel="stylesheet">

</head>

<body>

<div class="container">

  <div class="info">
    <h1>LOGIN</h1>
    
  </div>
</div>
<div class="form">


  <div class="login">
  <form role="search" action="/login2" method="post">
    <input type="text" class="form-control" name="login" id="login" placeholder="Login"/>
    <input type="password" class="form-control" name="password" id="password" placeholder="Senha"/>
   <B><button>ENTRAR</button></B>
  </form>
</div>

 
</body>
</html>

