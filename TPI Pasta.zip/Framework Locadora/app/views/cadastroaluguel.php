<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Cadastro</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    </head>
    <body>
        <div class="container">
            <div clas="row" class"col s12" >
                <h3> ALUGUEL </h3>
            </div>
            <div class="row">
                <form class="col s12" method="post" action=" /salvaraluguel">
                    <div class="row">
                        <div class="input-field col s6">
                            <input  id="id" name="id" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="id">Digite O ID</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <input  id="id_cliente" name="id_cliente" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="id_cliente">Digite O ID_cliente</label>
                        </div>
                    </div>
                        <div class="input-field col s6">
                            <input  id="data_aluguel" name="data_aluguel" required type="date" class="validate" maxlength="55">
                            <label class="active" for="data_aluguel">data_aluguel</label>
                        </div>
                         <div class="input-field col s6">
                            <input  id="data_decolucao" name="data_devolucao" required type="date" class="validate" maxlength="55">
                            <label class="active" for="data_devolucao">data_devolucao</label>
                        </div>
                        <div class="input-field col s6">
                            <input  id="valor" name="valor" required type="numeric" class="validate" maxlength="55">
                            <label class="active" for="valor">valor</label>
                        </div>
                    </div>
                    
                    <button class="btn waves-effect waves-light" type="submit" name="action">Enviar
                    </button>
                </form>
            </div>
            </div>

                 <!-- ALTERAÇÃO DE FILMES ALUGADOS -->
      <div>
      <table>
  <thead>
  <tr>
    <th>  ID  </th>
    <th>  ID_CLIENTE  </th>
    <th>  DATA_ALUGUEL  </th>
    <th>  DATA_DEVOLUÇÃO  </th>
    <th>  VALOR</th>
  </tr>
  </thead>

  <tbody>
  <?php foreach ($dados as $v) { ?>
        <tr>
         <td>
            <?= $v['id'] ?>
         </td>
         <td>
            <?= $v['id_cliente'] ?>
         </td>
         <td>
            <?= $v['data_aluguel'] ?>
         </td>
         <td>
            <?= $v['data_devolucao'] ?>
         </td>
         <td>
            <?= $v['valor'] ?>
         </td>
        <?php } ?>
        </tr>
  </tbody>
  </table>
  </div>
            </div>
            </div>