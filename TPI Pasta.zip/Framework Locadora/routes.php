<?php
//rotas da aplicação
//a variável $uri já contém os dados da rota solicitada

switch ($uri) {
    
    case '/':
       
        $dadosController->index();
        break;

    case '/index':
       
        require './app/views/index.php';
        break;
   
    case '/cadastro':

        require './app/views/cadastro.php';
        break;

    case '/salvarfilme':

        $dadosController->salvarfilme();
        break;

         case '/salvarcliente':

        $dadosController->salvarcliente();
        break;

        case '/salvaraluguel':

        $dadosController->salvaraluguel();
        break;

        case '/salvarhas2':

        $dadosController->salvarhas2();
        break;   
           
    default:
        die('Essa rota não é valida');
        break;

    case '/catalogo':

        $dadosController->catalogo();
        break;

    case '/lancamento':
        $dadosController->lancamento();
        break;    

     case '/cadastrofilme':
        $dadosController->cadastrofilme();
        break;   
     
   case '/admin_pagina':

       require './app/views/admin_pagina.php';
        break;  

      case '/cadastrofilme':
       
        require './app/views/cadastrofilme.php';
        break;

        case '/cadastrocliente':
        $dadosController->cliente();
        
        break;

     case '/cadastroaluguel':
       
         $dadosController->aluguel();
        break;

        case '/salvarhas':
       
         require './app/views/salvarhas.php';
        break;


        case '/login':
            require './app/views/login.php';
            
        break;

        case '/login2':
            $loginController->login();
            
        break;

    
        case '/logout':
        
        $loginController->logout();
        break;


        

}
